import React from 'react'
import './App.css';
import SearchPage from './Components/SearchPage';
import MainPage from './Components/MainPage.js'
import SlideDrawer from './SlideDrawer/SlideDrawer.js'
import Backdrop from './SlideDrawer/Backdrop.js'

class App extends React.Component {

  state = { drawerOpen: false }
  drawerToggleClickHandler = () => {
      this.setState({
        drawerOpen: !this.state.drawerOpen
      })
    }
  backdropClickHandler = () => {
      this.setState({
        drawerOpen: false
      })
    }
  render(){
    let backdrop;
    if(this.state.drawerOpen){
      backdrop = <Backdrop close={this.backdropClickHandler}/>;
     }
     return(
    <div >
    <SearchPage/>

       < SlideDrawer show={this.state.drawerOpen} />
           { backdrop }
           < MainPage toggle={this.drawerToggleClickHandler} />

    </div>
     )
    }
} 


export default App;
